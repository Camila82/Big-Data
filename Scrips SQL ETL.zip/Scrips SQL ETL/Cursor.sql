SET NOCOUNT ON;

TRUNCATE TABLE dbo.Personas_Clean;          -- permite re-ejecutar el proceso
TRUNCATE TABLE dbo.Personas_Rejected;

-- Variables con los valores originales (raw) y limpios
DECLARE @Id INT,
        @DocTipoRaw NVARCHAR(50),  @DocNumRaw NVARCHAR(100),
        @Nom1Raw NVARCHAR(200),     @Nom2Raw NVARCHAR(200),
        @Ape1Raw NVARCHAR(200),     @Ape2Raw NVARCHAR(200),
        @IngRaw NVARCHAR(100),      @GasRaw NVARCHAR(100);

DECLARE @DocTipo NVARCHAR(20),     @DocNum NVARCHAR(100),
        @Nom1 NVARCHAR(200),        @Nom2 NVARCHAR(200),
        @Ape1 NVARCHAR(200),        @Ape2 NVARCHAR(200),
        @Ingreso DECIMAL(18,2),    @Gasto DECIMAL(18,2), @Balance DECIMAL(18,2),
        @Motivo NVARCHAR(500);

DECLARE @Procesados INT = 0, @Aceptados INT = 0, @Rechazados INT = 0;

-- (1) DECLARE: declaracion del cursor
DECLARE cur_personas CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR
    SELECT TRY_CAST(SourceRowId AS INT),
           DocumentType, DocumentNumber,
           FirstName, MiddleName, LastName, SecondLastName,
           MonthlyIncome, MonthlyExpenses
    FROM dbo.Personas$
    WHERE TRY_CAST(SourceRowId AS INT) BETWEEN 1 AND 100
    ORDER BY TRY_CAST(SourceRowId AS INT);

-- (2) OPEN: apertura
OPEN cur_personas;

-- (3) FETCH: lectura de la primera fila
FETCH NEXT FROM cur_personas
INTO @Id, @DocTipoRaw, @DocNumRaw, @Nom1Raw, @Nom2Raw, @Ape1Raw, @Ape2Raw, @IngRaw, @GasRaw;

-- (4) WHILE @@FETCH_STATUS: recorrido
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @Procesados += 1;
    SET @Motivo = N'';

    -- 2a. Limpieza y estandarizacion
    SET @DocTipo = UPPER(dbo.fn_LimpiarTexto(@DocTipoRaw));   -- 'cc' -> 'CC'
    SET @DocNum  = dbo.fn_LimpiarTexto(@DocNumRaw);
    SET @Nom1    = dbo.fn_NombrePropio(dbo.fn_LimpiarTexto(@Nom1Raw));
    SET @Nom2    = dbo.fn_NombrePropio(dbo.fn_LimpiarTexto(@Nom2Raw));
    SET @Ape1    = dbo.fn_NombrePropio(dbo.fn_LimpiarTexto(@Ape1Raw));
    SET @Ape2    = dbo.fn_NombrePropio(dbo.fn_LimpiarTexto(@Ape2Raw));

    -- 2b. Validacion de documento y nombres
    IF @DocNum IS NULL OR UPPER(@DocNum) = N'SIN-DATO'
        SET @Motivo += N'Documento faltante; ';
    IF @Nom1 IS NULL
        SET @Motivo += N'Primer nombre faltante; ';
    IF @Ape1 IS NULL
        SET @Motivo += N'Primer apellido faltante; ';

    -- 2c. Conversion y validacion de importes
    SET @Ingreso = dbo.fn_ToDecimal(@IngRaw);
    SET @Gasto   = dbo.fn_ToDecimal(@GasRaw);

    IF dbo.fn_LimpiarTexto(@IngRaw) IS NULL
        SET @Motivo += N'MonthlyIncome faltante; ';
    ELSE IF @Ingreso IS NULL
        SET @Motivo += N'MonthlyIncome no numerico (' + @IngRaw + N'); ';
    ELSE IF @Ingreso < 0
        SET @Motivo += N'MonthlyIncome negativo; ';

    IF dbo.fn_LimpiarTexto(@GasRaw) IS NULL
        SET @Motivo += N'MonthlyExpenses faltante; ';
    ELSE IF @Gasto IS NULL
        SET @Motivo += N'MonthlyExpenses no numerico (' + @GasRaw + N'); ';
    ELSE IF @Gasto < 0
        SET @Motivo += N'MonthlyExpenses negativo; ';

    -- 2d. Destino segun resultado
    IF @Motivo = N''
    BEGIN
        SET @Balance = @Ingreso - @Gasto;    -- puede ser negativo y sigue siendo valido

        INSERT INTO dbo.Personas_Clean
            (SourceRowId, DocumentType, DocumentNumber, FirstName, MiddleName,
             LastName, SecondLastName, MonthlyIncome, MonthlyExpenses, MonthlyBalance)
        VALUES
            (@Id, @DocTipo, @DocNum, @Nom1, @Nom2, @Ape1, @Ape2, @Ingreso, @Gasto, @Balance);

        SET @Aceptados += 1;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.Personas_Rejected
            (SourceRowId, RejectReason, DocumentType_Original, DocumentNumber_Original,
             FirstName_Original, LastName_Original, MonthlyIncome_Original, MonthlyExpenses_Original)
        VALUES
            (@Id, LEFT(@Motivo, LEN(@Motivo) - 1),   -- quita el ultimo ';'
             @DocTipoRaw, @DocNumRaw, @Nom1Raw, @Ape1Raw, @IngRaw, @GasRaw);

        SET @Rechazados += 1;
    END;

    -- (3 otra vez) FETCH: siguiente fila
    FETCH NEXT FROM cur_personas
    INTO @Id, @DocTipoRaw, @DocNumRaw, @Nom1Raw, @Nom2Raw, @Ape1Raw, @Ape2Raw, @IngRaw, @GasRaw;
END;

-- (5) CLOSE: cierre
CLOSE cur_personas;

-- (6) DEALLOCATE: liberacion
DEALLOCATE cur_personas;

-- Resumen del proceso
SELECT @Procesados AS RegistrosProcesados,
       @Aceptados  AS RegistrosAceptados,
       @Rechazados AS RegistrosRechazados;
GO