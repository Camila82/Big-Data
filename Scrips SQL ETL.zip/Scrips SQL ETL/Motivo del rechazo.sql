SELECT 
    RejectReason,
    COUNT(*) AS Cantidad
FROM dbo.Personas_Rejected
GROUP BY RejectReason
ORDER BY Cantidad DESC;