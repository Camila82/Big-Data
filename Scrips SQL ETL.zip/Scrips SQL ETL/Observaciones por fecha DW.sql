SELECT t.Anio,
       t.Mes,
       SUM(f.CantidadObservaciones) AS Observaciones
FROM dbo.FactObservacion f
JOIN dbo.DimTiempo t ON t.TiempoKey = f.TiempoKey
GROUP BY t.Anio, t.Mes
ORDER BY t.Anio, t.Mes;