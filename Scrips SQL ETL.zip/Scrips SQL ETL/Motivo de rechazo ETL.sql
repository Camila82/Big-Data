-- Fechas corregidas: original dd/mm/aaaa frente a la fecha cargada
SELECT TOP 10 o.SourceRowId, o.BirthDate AS NacimientoOriginal, l.FechaNacimiento AS NacimientoCargado
FROM dbo.[Personas$] o
JOIN dbo.STG_LIMPIO_ENCUESTA l ON l.SourceRowId = TRY_CAST(o.SourceRowId AS int)
WHERE o.BirthDate LIKE '%/%';
 
-- Fechas inválidas que fueron a rechazo o revisión
SELECT r.Estado, r.Motivos, COUNT(*) AS Filas
FROM dbo.ETL_RECHAZO_ENCUESTA r
WHERE (r.Motivos LIKE '%FECHA%' OR r.Motivos LIKE '%ANTERIOR%' OR r.Motivos LIKE '%POSTERIOR%') AND r.FechaProceso = (SELECT MAX(FechaProceso) FROM dbo.ETL_RECHAZO_ENCUESTA)
GROUP BY r.Estado, r.Motivos ORDER BY Filas DESC;
