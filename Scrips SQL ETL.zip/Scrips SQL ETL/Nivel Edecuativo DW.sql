SELECT e.NivelEducativo,
       COUNT(*)                              AS Observaciones,
       CAST(AVG(f.IngresoMensual) AS decimal(15,2)) AS IngresoPromedio
FROM dbo.FactObservacion f
JOIN dbo.DimEducacion e ON e.EducacionKey = f.EducacionKey
GROUP BY e.NivelEducativo
ORDER BY IngresoPromedio DESC;