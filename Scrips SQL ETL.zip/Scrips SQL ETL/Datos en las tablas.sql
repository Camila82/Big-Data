SELECT 'DimTiempo' AS Tabla, COUNT(*) AS Filas FROM PersonasETL_DW.dbo.DimTiempo UNION ALL
SELECT 'DimUbicacion', COUNT(*) FROM PersonasETL_DW.dbo.DimUbicacion UNION ALL
SELECT 'DimEducacion', COUNT(*) FROM PersonasETL_DW.dbo.DimEducacion UNION ALL
SELECT 'DimSituacionLaboral', COUNT(*) FROM PersonasETL_DW.dbo.DimSituacionLaboral UNION ALL
SELECT 'DimPersona', COUNT(*) FROM PersonasETL_DW.dbo.DimPersona UNION ALL
SELECT 'FactObservacion', COUNT(*) FROM PersonasETL_DW.dbo.FactObservacion;