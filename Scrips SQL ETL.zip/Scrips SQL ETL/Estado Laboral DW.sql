SELECT s.EstadoLaboral,
       COUNT(*)                              AS Observaciones,
       CAST(AVG(f.BalanceMensual) AS decimal(15,2)) AS BalancePromedio
FROM dbo.FactObservacion f
JOIN dbo.DimSituacionLaboral s ON s.SituacionLaboralKey = f.SituacionLaboralKey
GROUP BY s.EstadoLaboral
ORDER BY BalancePromedio DESC;