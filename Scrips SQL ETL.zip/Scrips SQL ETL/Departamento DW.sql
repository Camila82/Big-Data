USE PersonasETL_DW;

SELECT u.DepartamentoNombre,
       u.MunicipioNombre,
       COUNT(DISTINCT f.PersonaKey) AS PersonasDistintas
FROM dbo.FactObservacion f
JOIN dbo.DimUbicacion u ON u.UbicacionKey = f.UbicacionKey
GROUP BY u.DepartamentoNombre, u.MunicipioNombre
ORDER BY PersonasDistintas DESC, u.MunicipioNombre;